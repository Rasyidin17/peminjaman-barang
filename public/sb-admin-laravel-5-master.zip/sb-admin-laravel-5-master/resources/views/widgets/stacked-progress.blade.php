<div class="progress">
  <div class="progress-bar {{ $class1 }}" style="width: {{ $value1 }}%">
    <span class="sr-only">35% Complete (success)</span>
  </div>
  <div class="progress-bar {{ $class2 }}" style="width: {{ $value2 }}%">
    <span class="sr-only">20% Complete (warning)</span>
  </div>
  <div class="progress-bar {{ $class3 }}" style="width: {{ $value3 }}%">
    <span class="sr-only">10% Complete (danger)</span>
  </div>
</div>